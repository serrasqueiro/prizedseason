#ifndef iLIB_OBJS_X_H
#define iLIB_OBJS_X_H

#include "iobjs.h"

#include "istorage.h"
#include "istring.h"
#include "icontrol.h"
#include "ilist.h"

#include "iarg.h"
#include "ibase.h"
#include "icalendar.h"
#include "iconfig.h"
#include "idir.h"
#include "ifile.h"
#include "ifilestat.h"
#include "imath.h"
#include "inet.h"
#include "itime.h"
#include "iunicode.h"


#endif //iLIB_OBJS_X_H

