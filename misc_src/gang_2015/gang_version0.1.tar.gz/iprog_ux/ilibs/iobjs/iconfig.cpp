// iconfig.cpp

#include <string.h>

#include "iconfig.h"
////////////////////////////////////////////////////////////
gFileFetch::gFileFetch (int maxLines)
    : gFileText( NULL, false ),
      doEndNewLine( false ),
      maxNLines( maxLines ),
      isFetchBufferOk( true ),
      doResize( false ),
      doShowProgress( false ),
      fVRepErr( nil )
{
 // Do not use stdout as per gFile default!
 ASSERTION(f==stdout,"gFile default?");
 f = nil;
}


gFileFetch::gFileFetch (gString& sFName, int maxLines)
    : gFileText( sFName.Str(), true ),
      doEndNewLine( false ),
      maxNLines( maxLines ),
      isFetchBufferOk( true ),
      doResize( IsDevice()==false ),
      doShowProgress( false ),
      fVRepErr( nil )
{
 bool isOk;
 thisReadFile( isOk, aL );
}


gFileFetch::gFileFetch (char* fName, int maxLines, bool aShowProgress)
    : gFileText( fName, true ),
      doEndNewLine( false ),
      maxNLines( maxLines ),
      isFetchBufferOk( true ),
      doResize( IsDevice()==false ),
      doShowProgress( aShowProgress ),
      fVRepErr( nil )
{
 bool isOk;
 if ( fName==NULL || fName[0]==0 ) {
     OpenDevice( e_fStdin );
     ASSERTION(doShowProgress==false,"progress?");
 }
 else {
     if ( doShowProgress ) SetDeviceReport( e_fStderr );
 }
 thisReadFile( isOk, aL );
}


gFileFetch::gFileFetch (gString& sInput, bool aShowProgress)
    : gFileText( nil, false ),
      doEndNewLine( false ),
      maxNLines( -1 ),
      isFetchBufferOk( true ),
      doResize( false ),
      doShowProgress( aShowProgress ),
      fVRepErr( nil )
{
 if ( doShowProgress ) SetDeviceReport( e_fStderr );
 thisReadStringAsFile( sInput, aL );
}


gFileFetch::~gFileFetch ()
{
}


bool gFileFetch::SetFileReport (FILE* fRep)
{
 doShowProgress = fRep!=nil;
 fVRepErr = fRep;
 return doShowProgress;
}


bool gFileFetch::SetDeviceReport (eDeviceKind aDKind)
{
 fVRepErr = nil;
 switch ( aDKind ) {
 case e_fDevOther:
 case e_fStdin:
     return false;
 case e_fStdout:
     fVRepErr = stdout;
     break;
 case e_fStderr:
     fVRepErr = stderr;
     break;
 default:
     return false;
 }
 // doShowProgress is here updated as well...
 return SetFileReport( fVRepErr );
}


bool gFileFetch::Fetch (gString& sFName)
{
 bool isOk;
 int res;

 isOk = sFName.IsEmpty()==false && OpenToRead( sFName.Str() )==true;
 DBGPRINT_MIN("DBG: Fetch(%s) Ok? %c (lastOpError=%d) f=%p (%d)\n",
	      sFName.Str(),
	      ISyORn( isOk ),
	      lastOpError,
	      f,
	      f==stdin);
 if ( isOk==false ) return false;
 res = thisReadFile( isOk, aL );
 DBGPRINT_MIN("DBG: thisReadFile(): res=%d\n",res);
 return isOk && res!=2;
}


int gFileFetch::thisReadFile (bool& isOk, gList& zL)
{
 int error = 0;
 t_uint32 nBytes;

 if ( IsOpened()==false ) return 2;

 error = thisReadAll( isOk, isFetchBufferOk, zL );
 if ( error!=0 ) return error;
 if ( doResize==false ) return error;

 ASSERTION(IsDevice()==false,"IsDevice()==false");
 // Check if there was a buffer overun
 if ( isFetchBufferOk ) return 0;
 // Empty list meanwhile used: zL
 zL.Delete();
 if ( Rewind()==false ) return 1;
 thisReadFileThrough( zL, nBytes );
 error = nBytes<Size() ? 4 : 0;
 //if ( error!=0 ) fprintf(stderr,"DBG::: nBytes=%ld, size()=%ld\n",(long)nBytes,(long)Size())
 isFetchBufferOk = error==0;
 return error;
}

int gFileFetch::thisReadAll (bool& isOk, bool& isBufOk, gList& zL)
{
 int iCount=0;

 isBufOk = true;

 while ( ReadLine( isOk, doEndNewLine ) ) {
     iCount++;
     if ( maxNLines>=0 && iCount>maxNLines ) {
	 doEndNewLine = true;
	 return lastOpError = -9;
     }

     zL.Add( Buffer() );
     if ( isBufferOk==false ) isBufOk = false;
 }
 isOk = true;

 return 0;
}


int gFileFetch::thisReadFileThrough (gList& zL, t_uint32& nBytes)
{
 int iChr;
 t_uchar c;
 gString s;
 t_uint32 aSize = Size();

 nBytes = 0;
 while ( (iChr = fgetc( f ))>=0 ) {
     c = (t_uchar)iChr;
     nBytes++;
     if ( c=='\r' ) continue;
     if ( c=='\n' ) {
	 zL.Add( s );
	 s.SetEmpty();
	 if ( doShowProgress ) {
	     fprintf(fVRepErr,"%ld of %ld\r",(long)nBytes,(long)aSize);
	     fflush( fVRepErr );
	 }
	 continue;
     }
     s.Add( c );
 }
 if ( doShowProgress ) {
     fprintf(fVRepErr,".%20s\n"," ");
 }
 if ( s.IsEmpty() ) return 0;
 zL.Add( s );
 return 0;
}


int gFileFetch::thisReadStringAsFile (gString& sInput, gList& zL)
{
 unsigned i, len=sInput.Length();
 char* str;  //for quickness
 char chr;

 gString sLine;
 for (i=0, str=sInput.Str(); i<len; i++) {
     chr = str[i];
     if ( chr=='\r' ) continue;
     if ( chr=='\n' ) {
	 zL.Add( sLine );
	 sLine.SetEmpty();
     }
     else {
	 sLine.Add( chr );
     }
 }
 doEndNewLine = sLine.IsEmpty();
 if ( doEndNewLine==false ) zL.Add( sLine );
 return 0;
}
////////////////////////////////////////////////////////////

