// debug.cpp, for libiobjs

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lib_iobjs.h"


// COMPILE
//	make debug
//
// USAGE:
//	debug [-|hash] [ARGS]
//
// Examples:
//	debug aString
//		-> dumps hash of aString
//	debug - Abc
//		-> dumps the unsigned hash of Abc
//
//	debug hash file1 file2
//		-> dumps line hashes of file1 and file2
//

////////////////////////////////////////////////////////////
int file_show_hash (FILE* fIn, FILE* fOut)
{
 gString s;
 char chr;

 ASSERTION(fIn,"fIn");
 ASSERTION(fOut,"fOut");

 for ( ; fscanf(fIn,"%c",&chr)==1; ) {
     if ( chr=='\n' ) {
	 fprintf(fOut,"%u\t%s\n",
		 s.Hash(),
		 s.Str());
	 s.Reset();
     }
     else {
	 if ( chr!='\r' ) {
	     s.Add( chr );
	 }
     }
 }

 if ( s.Length() ) {
     fprintf(fOut,"%u\t%s\n",
	     s.Hash(),
	     s.Str());
 }
 return 0;
}


int dbg_test (const char* strIn)
{
 int error;
 gString sNew( (char*)strIn );
 bool isOk( sNew.IsOk() );

 error = isOk==false;

 printf("sNew.Str()='%s' (strIn %s), iValue: %d\n",
	sNew.Str(),
	strIn ? (isOk ? "OK" : "uops!") : "nil",
	sNew.Hash());

 return error;
}


int dbg_test_unsigned (const char* strIn, unsigned modulus)
{
 gString sNew( (char*)strIn );

 if ( modulus ) {
     printf("Hash value (modulus %u%s, next prime: %u): %u\n",
	    modulus,
	    ibase_Prime( modulus ) ? " - PRIME NUMBER" : "",
	    ibase_NextPrime( modulus ),
	    (unsigned)sNew.Rehash() % modulus);
 }
 else {
     printf("Hash value: %u\n",(unsigned)sNew.Rehash());
 }
 return 0;
}


int dbg_hash (char* args[])
{
 int error( 0 );
 const char* str;
 FILE* fIn( stdin );
 FILE* fOut( stdout );

 if ( args==nil || args[ 0 ]==nil || args[ 1 ]==nil ) {
     file_show_hash( fIn, fOut );
 }
 else {
     for (args++; (str = *args)!=nil; args++) {
	 fIn = fopen( str, "rt" );
	 if ( fIn ) {
	     file_show_hash( fIn, fOut );
	     fclose( fIn );
	 }
	 else {
	     fprintf(stderr,"Uops: %s\n",str);
	 }
     }
 }

 return error;
}



int do_debug (int argc, char* argv[])
{
 int error;
 const char* strArg1( argv[ 1 ] );

 if ( strArg1 ) {
     if ( strcmp( strArg1, "hash" )==0 ) {
	 return dbg_hash( argv+1 );
     }
 }

 if ( strArg1 && strArg1[ 0 ]=='-' ) {
     error = dbg_test_unsigned( argv[ 2 ], -atoi( strArg1 ) );
 }
 else {
     error = dbg_test( strArg1 );

     printf("gFileControl::Self().userId: %d, tmpPath: {%s}\n",
	    gFileControl::Self().userId,
	    gFileControl::Self().tmpPath);
     fprintf(stderr,"Error: %d\n",error);
 }

 return error!=0;
}


int main (int argc, char* argv[])
{
 int error;

 gINIT;

 DBGPRINT("DBG: Objs: %d\n",gStorageControl::Self().NumObjs());
 error = do_debug( argc, argv );
 DBGPRINT("DBG: Objs undeleted: %d\n",gStorageControl::Self().NumObjs());

 gEND;

 return error;
}
////////////////////////////////////////////////////////////

