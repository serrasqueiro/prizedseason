// debug.cpp, for libimedia

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lib_imedia.h"


#ifndef DEBUG_OUT_PATH
#define DEBUG_OUT_PATH "/mnt/tmp"
#endif

#define DBG_PATH_SLASH DEBUG_OUT_PATH "/"

#define TMP_OUT_1 DBG_PATH_SLASH "isw.debug.txt"
#define TMP_OUT_2 DBG_PATH_SLASH "isw.debug.2.txt"
#define TMP_OUT_3 DBG_PATH_SLASH "isw.debug.3.txt"


#define STR_LATIN1_a_tilde "�"


// Globals
sIsoUni uniData;


////////////////////////////////////////////////////////////
int ptm_prepare_custom_iso (int optTable, sIsoUni& data)
{
 int idx( 0 );
 char* myUcs8( data.customUcs8[ 3 ] );
 bool isInitialized( myUcs8[ 0 ]==0 );
 char hashed;
 t_uchar uChr;
 gUniCode* inUse( data.inUse );

 // ----> This function was copied almost 100% from boradb/src/processtext.cpp

 if ( isInitialized ) return -1;  // Nothing to do again

 ASSERTION(data.hashUcs16Eq==nil,"hashUcs16Eq==nil");
 ASSERTION(inUse,"inUse");

 data.hashUcs16Eq = new t_uchar*[ 256 ];
 ASSERTION(data.hashUcs16Eq,"hashUcs16Eq");

 for ( ; idx<256; idx++) {
     if ( idx<' ' ) {
	 data.hashUcs16Eq[ idx ] = new t_uchar[ 2 ];
	 data.hashUcs16Eq[ idx ][ 0 ] = data.hashUcs16Eq[ idx ][ 0 ] = 0;
     }
     else {
	 data.hashUcs16Eq[ idx ] = new t_uchar[ 4 ];
	 memset( data.hashUcs16Eq[ idx ], 0x0, 4 );
     }
 }

 for (idx=0; idx<' '; idx++) {
     myUcs8[ idx ] = 0;
 }

 for ( ; idx<127; idx++) {
     hashed = data.hashUcs8Custom[ idx ];
     myUcs8[ idx ] = hashed;
 }

 for ( ; idx<256; idx++) {
     hashed = data.hashUcs8Custom[ idx ];
     if ( hashed==-1 ) {
	 hashed = '~';
     }
     else {
	 uChr = (t_uchar)hashed;
	 hashed = inUse->hash256User[ gUniCode::e_Basic_Alpha26 ][ idx ];

	 if ( hashed==0 || hashed==-1 ) {
		 hashed = (char)idx;
	 }
	 else {
	     data.hashUcs16Eq[ idx ][ 0 ] = hashed;
	     data.hashUcs16Eq[ idx ][ 1 ] = 0;
	 }
     }
     myUcs8[ idx ] = hashed;
 }

 for (uChr='A'; uChr<='Z'; uChr++) {
     data.hashUcs16Eq[ uChr ][ 0 ] = uChr;
     ASSERTION(data.hashUcs16Eq[ uChr ][ 1 ]==0,"!iso (1)");
 }
 for (uChr='a'; uChr<='z'; uChr++) {
     data.hashUcs16Eq[ uChr ][ 0 ] = uChr;
     ASSERTION(data.hashUcs16Eq[ uChr ][ 1 ]==0,"!iso (2)");
 }
 for (uChr=47; uChr<='9'; uChr++) {
     idx = uChr==47 ? ' ' : (int)uChr;
     data.hashUcs16Eq[ idx ][ 0 ] = idx<'0' ? ' ' : idx;
     ASSERTION(data.hashUcs16Eq[ idx ][ 1 ]==0,"!iso (3)");
 }

 // German special chars, accepted:
 myUcs8[ 0xDF ] = 0xDF;		// 'LETTER SHARP S
 myUcs8[ 0xFF ] = 0;

 // also to the custom UCS8:
 data.hashUcs8Custom[ 0xDF ] = 0xDF;
 strcpy( (char*)data.hashUcs16Eq[ 0xDF ], "ss" );

 data.RefactorUcs16Eq();

 // Adjust blank and '_' into '.'
 strcpy( (char*)data.hashUcs16Strs[ ' ' ], "." );
 strcpy( (char*)data.hashUcs16Strs[ '_' ], "." );

 return 0;
}


int dbg_dump_cdb (FILE* fOut, int fdIn, int optUnused)
{
 sCdpCdb cdp;
 int error( acdb_read( fdIn, cdp ) );
 return error;
}

////////////////////////////////////////////////////////////
int dbg_test (const char* strIn)
{
 int error;
 int iLine( -1 ), prevLine( -1 );
 int thisMask, lastMask( -1 );
 gElem* ptrElem;
 gWebChassis chassis;
 gList listHTML, outHTML;
 FILE* fOut( stdout );
 FILE* fDbg( nil );
 FILE* fDbg3( nil );

 const char* strEnd( "\n" );
 const char* strFinit( strEnd );

 error = isw_simple_html_filter_file( strIn, outHTML, chassis );

 gString sFirstLine( outHTML.Str( 1 ) );
 if ( sFirstLine[ 1 ]=='#' && sFirstLine.Find( " Player " )>0 ) {
     fDbg = fopen( strIn, "r" );
     if ( fDbg ) {
	 error = dbg_dump_cdb( fOut, fileno( fDbg ), 0 );
	 fclose( fDbg );
	 fprintf(stderr,"cdb read: %d\n",error);
	 return -1;
     }
     else {
	 fprintf(stderr,"Uops: %s\n",strIn);
     }
 }

 printf("dbg_test: {%s}\n\
>>>>\n",strIn);

 for (ptrElem=outHTML.StartPtr();
      ptrElem;
      ptrElem=ptrElem->next) {

     #ifdef DEBUG_MIN
     imd_print_error("%d: ",ptrElem->iValue);
     #endif
     fprintf(fOut,"%d:%s\n",ptrElem->iValue,ptrElem->Str());
 }

 imd_print_error("\n\n");
 printf("<<<<\n\n");

 fOut = fopen( TMP_OUT_1, "wt" );
 if ( fOut==nil ) return 13;

#ifdef ISW_DEBUG_RAW
 fDbg = fopen( TMP_OUT_2, "wt" );
 fDbg3= fopen( TMP_OUT_3, "wt" );
#endif

 for (ptrElem=chassis.StartPtr();
      ptrElem;
      ptrElem=ptrElem->next) {

     const char* strBefore( "\0" );
     gString* aStr( (gString*)ptrElem->me );

     ASSERTION(aStr,"chassis?!");

     iLine = ptrElem->iValue;
     thisMask = aStr->iValue;

     if ( fDbg ) {
	 fprintf(fDbg,"%d, %d:\t%s\n",
		 iLine,
		 thisMask,
		 ptrElem->Str());
     }

     if ( iLine==prevLine ) {
	 strFinit = "";
	 if ( lastMask==ISW_MASK_QUOTED ) {
	     if ( aStr->Match( "/>" ) || (*aStr)[ 1 ]=='>' ) {
		 // do not add a blank after quote,
		 // e.g. '<a href="quote"' then '>' is added without blank,
		 // like this:  <a href="quote">
		 // instead of: <a href="quote" >
	     }
	     else {
		 strBefore = " ";
	     }
	 }

	 lastMask = aStr->iValue;
     }
     else {
	 strFinit = strEnd;
	 lastMask = -1;
     }
     fprintf(fOut,"%s%s%s",
	     strBefore,
	     strFinit,
	     ptrElem->Str());

     prevLine = iLine;
 }

 fprintf(fOut,strEnd);

 fclose( fOut );
 if ( fDbg ) fclose( fDbg );

 // Now the chassis built up!
 if ( fDbg3 ) {
     isw_html_keydump( chassis, chassis );

     for (ptrElem=chassis.built.StartPtr();
	  ptrElem;
	  ptrElem=ptrElem->next) {

	 if ( ptrElem->me->IsString() ) {
	     fprintf(fDbg3,"%s\n",ptrElem->Str());
	 }
	 else {
	     gElem* ptrFollow( ((gList*)ptrElem->me)->StartPtr() );
	     for ( ; ptrFollow; ptrFollow=ptrFollow->next) {
		 fprintf(fDbg3,"%s",ptrFollow->Str());
	     }
	 }
     }
 }

 FILE* fErLog( stderr );
 gString* errStr;

 for (ptrElem=chassis.htmlStatus.logIncompleteQuote.StartPtr();
      ptrElem;
      ptrElem=ptrElem->next) {
     errStr = (gString*)ptrElem->me;
     fprintf(fErLog, "Line: %d, mask: %d:\n\t%s\n\n\n",
	     ptrElem->iValue,
	     errStr->iValue,
	     errStr->Str());
 }

 return error;
}


int dbg_samples (const char* strOneMore)
{
 const char* strSamples[]={
	"The Verve",
	"Smiths, The",
	"Pink,_Floyd",
	"Rodrigo Le" STR_LATIN1_a_tilde "o",
	nil,
	nil,
	nil
 };

 const char* str;
 const char* newStr( nil );
 int idx( 0 );
 gList* newList;
 gStorage* me;

 for ( ; (str = strSamples[ idx ])!=nil; idx++) ;
 if ( strOneMore ) {
     strSamples[ idx ] = strOneMore;
 }

 printf("LEGEND:\n\
	+r	Original string\n\
	+h	ptm_nprime(); comma separated upstring\n\
	+x	same as +r\n\
	+y	dotted with original upstring\n\
\n");

 for (idx=0; (str = strSamples[ idx ])!=nil; idx++) {
     gString sName( (char*)str );

     newList = ptm_new_name( sName, nil, 0, nil );
     if ( newList ) {
	 me = newList->StartPtr()->next->me;
	 newStr = me->Str();
	 printf("\
+r		  %s\n\
+h	%08u  %s\n",
		str,
		ptm_nprime( me->iValue ),
		newStr);
	 delete newList;
     }
     else {
	 printf("\
+r			%s\n\
+h	%08u  <NADA>\n",
		str,
		-1);
     }

     printf("\
+x		  %s\n\
+y		  %s\n\n",
	    str,
	    ptm_name_str( str, 1, nil ));
 }
 return 0;
}



int dbg_cue (const char* strFile)
{
 int error;
 gFileFetch cueInput( (char*)strFile );
 iCue cue;
 FILE* fOut( stdout );

 error = cue.Parse( cueInput.aL );

 fprintf(fOut, "DiscID: {%s}\nPerformer: {%s}\nTitle: {%s}\nFile: {%s}\nComment: {%s}",
	 cue.sDiscID.Str(),
	 cue.sPerformer.Str(),
	 cue.sTitle.Str(),
	 cue.sFile.Str(),
	 cue.sComment.Str());

 return error;
}


int do_debug (int argc, char* argv[])
{
 int error;

 if ( str_compare( argv[ 1 ], "cue" )==0 ) {
     error = dbg_cue( argv[ 2 ] );
     return error;
 }
 else {
     error = dbg_test( argv[ 1 ] );
 }

 if ( error<0 ) return 0;
 fprintf(stderr,"Error: %d\n",error);

 error = ptm_prepare_custom_iso( 0, uniData );
 printf("ptm_prepare_custom_iso returned: %d\n",error);

 dbg_samples( argv[ 1 ] );

 gString* ptrStr( imb_auth_mime64( (t_uchar*)"henry", (t_uchar*)"pass" ) );

 if ( ptrStr ) {
     printf("Base64 for henry,pass: %s\n",ptrStr->Str());
     delete ptrStr;
 }

#ifndef NO_TEST_UTF8
 eRecodeError returnError( ereNO_ERROR );
 t_uchar* newStr( imb_utf8_str_to_ucs2( (t_uchar*)"Susana Félix - Flutuo", returnError ) );

 printf("ISO8859-1 got returnError=%d, {%s}\n",
	returnError,
	newStr);
 delete[] newStr;
#endif

 return error!=0;
}


int main (int argc, char* argv[])
{
 int error;

 gINIT;

 imb_iso_init( nil, uniData );

 error = do_debug( argc, argv );

 FILE* fOutput( gFileControl::Self().OutputStream() );
 FILE* fReport( gFileControl::Self().ReportStream() );
 gStorageControl::Self().Show();
 printf("fOutput: %s\n",
	fOutput ? (fOutput==stdout ? "stdout" : "<other>") : "nil");
 printf("fReport: %s\n",
	fReport ? (fReport==stderr ? "stderr" : (fReport==stdout ? "stdout" : "<other>")) : "nil");

 imb_iso_release();

 ISW_SHOW_MEM("DBG: Objs undeleted: %d\n",gStorageControl::Self().NumObjs());
 gEND;

 return error;
}
////////////////////////////////////////////////////////////

