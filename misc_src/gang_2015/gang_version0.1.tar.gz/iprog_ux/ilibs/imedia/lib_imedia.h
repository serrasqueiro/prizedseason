#ifndef LIB_IMEDIA_X_H
#define LIB_IMEDIA_X_H

#define LIB_IMEDIA_VERSION_MAJOR	2
#define LIB_IMEDIA_VERSION_MINOR	0

#include "inames.h"
#include "ibases.h"
#include "isweb.h"
#include "isoconv.h"

#include "iplaylist.h"
#include "acdb.h"
#include "entry.h"
#include "cue.h"


#if defined(DEBUG) || defined(DEBUG_MIN)
#define imd_print_error(args...) fprintf(stderr,args)
#else
#define imd_print_error(args...) ;
#endif


#endif //LIB_IMEDIA_X_H

