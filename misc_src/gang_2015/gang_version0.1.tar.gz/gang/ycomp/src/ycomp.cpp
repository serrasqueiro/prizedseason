// ycomp
//
// A simple yang compiler.


#define thisProgramVersion "Version 0.1"
#define thisProgramCopyright "Henrique Moreira"
#define thisProgramYear 2015
#define thisProgramCopy "This is free software (GPL)\n\
There is no warranty, not even for MERCHANTABILITY or\n\
FITNESS FOR A PARTICULAR PURPOSE."

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#include "iarg.h"

#include "lib_imedia.h"


#ifdef iDOS_SPEC
#include <windows.h>
#endif //iDOS_SPEC

#include "iodeconv.h"
#include "yskel.h"


#define YCOMP_CONFIG_FILE "YCOMP_CONFIG"
#define YCOMP_CONFIG_NAME "ycomp.config"

////////////////////////////////////////////////////////////
struct sOptSed {
    sOptSed ()
	: isVerbose( false ),
	  isVeryVerbose( false ),
	  verboseLevel( 0 ),
	  doAll( false ),
	  zValue( -1 ) {
    }

    ~sOptSed () {
    }

    bool isVerbose, isVeryVerbose;
    int verboseLevel;
    bool doAll;
    int zValue;

    gString sConfig;
    gString sOutput;
    gString sBasePath;

    gList myConfig;
};


// Globals
sIsoUni uniData;


////////////////////////////////////////////////////////////
int command_from_str (const char* cmdStr)
{
 int iter( 0 );
 const char* str;
 const sPair pairs[]={
     { 1, "test" },
     { 3, "simple" },
     { -1, nil },
     { -1, nil }
 };

 if ( cmdStr==nil ) return -1;
 for ( ; (str = pairs[ iter ].str)!=nil; iter++) {
     if ( cmdStr[0]!=0 && strcmp( str, cmdStr )==0 ) return pairs[ iter ].value;
 }
 return -1;
}


int print_help (char* progStr)
{
 char
     *msgHelp = "%s - %s\n\n\
Usage:\n\
        %s command [--help] [OPTION] [NAME ...]\n\
\n\
Commands are:\n\
   test              Test lib: dump iobjs and imedia major / minor version\n\
   simple            A simple yang parser\n\
\n\
Options are:\n\
   -h           This help (or --help / --version)\n\
   -v           Verbose (use twice, more verbose)\n\
   -c X         Use configuration file X (or --config)\n\
   -o X         Use output file X (or --output)\n\
";
 //   -z X         Z value: e.g. number of chars to convert
 printf(msgHelp,
	progStr,
	thisProgramVersion,
	progStr,
	progStr);
 return 0;
}


int print_help_command (char* cmdStr)
{
 int cmdNr;
 const char
     *msgHelpI[] = {
	 nil,
	 "%s %s [arg ...]\n\
\n\
Dump iobjs / imedia library major and minor versions.\n\
\n\
If any arg is given, it will show the string-hashes of each one.\n\
You can use -z M to specify the modulus of output.\n\
",
	 "%s : %s [arg ...]\n\
",	// 2
	 "%s %s [arg ...]\n\
",	// 3
	 "%s %s search-path [arg ...]\n\
\n\
Anchor: testing ONLY.\
",	// 4
	nil,
	// 11
	"%s %s TEST\n\
\n\
NADA\
",
	nil,
	nil,
	nil };

 cmdNr = command_from_str( cmdStr );
 if ( cmdNr<0 ) {
     printf("Invalid command: %s\n",cmdStr);
     return -1;
 }

 printf(msgHelpI[ cmdNr ],
	gFileControl::Self().sProgramName.Str(),
	cmdStr);
 return 0;
}

////////////////////////////////////////////////////////////
int print_version (char* progStr)
{
 char
     *msgVersion = "%s - %s\n\
\n\
Build \
001\
\n\
\n\
Copyright (C) %u %s.\n\
\n\
%s\n";

 printf(msgVersion,
	progStr,
	thisProgramVersion,
	thisProgramYear,thisProgramCopyright,
	thisProgramCopy);
 return 0;
}

////////////////////////////////////////////////////////////
// Aux functions
////////////////////////////////////////////////////////////
const char* config_default ()
{
 static char ssedConfName[ 256 ];
 const char* strConfig( getenv( YCOMP_CONFIG_FILE ) );

 memset(ssedConfName, 0x0, sizeof(ssedConfName));

 if ( strConfig==nil ) {
     const char* strApp( getenv( "APPDATA" ) );
     if ( strApp ) {
	 snprintf(ssedConfName, sizeof(ssedConfName)-1, "%s" gSLASHSTR YCOMP_CONFIG_NAME, strApp);
	 gFileStat aStat( ssedConfName );
	 if ( aStat.HasStat() && aStat.IsDirectory()==false ) strConfig = ssedConfName;
     }
 }

 return strConfig;
}


void extra_unis (gUniCode& uni)
{
 const t_uchar valids[]="\t\n";
 t_uchar uChr;

 for (short idx=0; (uChr = valids[ idx ])!=0; idx++) {
     uni.hash256Basic[ gUniCode::e_Basic_Printable ][ uChr ] = (char)uChr;
 }
}


int config_str_boolean (gString& sValue, int& error)
{
 gString sCheck( sValue );
 int value;

 sCheck.Trim();
 sCheck.UpString();
 value = sCheck.Match( "TRUE" ) || sCheck.Match( "YES" );
 error = (value==1 || sCheck.Match( "FALSE" ) || sCheck.Match( "NO" ))==0;
 DBGPRINT("DBG: config line: %d, error=%d, '%s' => value=%d\n",sValue.iValue,error,sValue.Str(),value);
 return value;
}


const char* config_bool_str (int value)
{
 return value ? "true" : "false";
}


gString* find_config (gList& myConfig, const char* strEq, gString& rValue)
{
 gString* ptrStr( nil );
 int pos;

 rValue.Reset();
 if ( myConfig.FindFirst( (char*)strEq, 1, e_FindExactPosition ) ) {
     ptrStr = (gString*)myConfig.CurrentPtr()->me;
     pos = (int)ptrStr->Find( '=' );
     if ( pos>0 ) {
	 rValue.Set( ptrStr->Str( pos ) );
	 rValue.iValue = atoi( rValue.Str() );
     }
 }
 return ptrStr;
}


gString* find_config_statement (gList& myConfig, const char* str, int& error)
{
 gString* ptrStr( nil );
 gString sEq( (char*)str );
 sEq.Add( '=' );

 if ( myConfig.FindFirst( (char*)str, 1, e_FindExactPosition ) ) {
     ptrStr = (gString*)myConfig.CurrentPtr()->me;

     // This function is to find statements (without rValue),
     // so, if any STATEMENT= is found, is an error.
     error = myConfig.FindFirst( sEq.Str(), 1, e_FindExactPosition )>0;
 }
 return ptrStr;
}


int generic_read_config (gList& input, gList& conf)
{
 int line( 0 );
 unsigned uPos;
 gElem* ptrElem( input.StartPtr() );

 for ( ; ptrElem; ptrElem=ptrElem->next) {
     line++;
     gString sLine( ptrElem->Str() );
     sLine.Trim();
     if ( sLine[ 1 ]=='#' || sLine.IsEmpty() ) continue;

     // Trim blanks before '='
     uPos = sLine.Find( '=' );
     if ( uPos>1 ) {
	 gString sCopy;
	 gString sRight;
	 sCopy.CopyFromTo( sLine, 1, uPos-1 );
	 sCopy.Trim();
	 sRight.CopyFromTo( sLine, uPos+1 );
	 sRight.Trim();
	 sLine = sCopy;
	 sLine.Add( '=' );
	 sLine.AddString( sRight );
     }
     conf.Add( sLine );
     conf.EndPtr()->me->iValue = line;
 }
 return 0;
}


int listed_read (gList& input, gList& lines)
{
 int line( 0 );
 gElem* ptrElem( input.StartPtr() );

 for ( ; ptrElem; ptrElem=ptrElem->next) {
     line++;
     gString sLine( ptrElem->Str() );
     if ( line==1 ) {
	 if ( sLine[ 1 ]=='#' ) {
	     lines.Add( sLine );
	     continue;
	 }
     }
     lines.Add( sLine );
     if ( sLine.Length() ) {
	 lines.EndPtr()->me->iValue = line;
     }
 }
 return 0;
}


int ycomp_read_config_file (const char* strConfigFile, FILE* fRepErr, gList& myConfig)
{
 int error( 0 );

 ASSERTION(fRepErr,"fRepErr");

 if ( strConfigFile==nil ) {
     strConfigFile = config_default();
 }
 if ( strConfigFile==nil || strConfigFile[ 0 ]==0 )
     return -1;

 gFileFetch config( (char*)strConfigFile );
 if ( config.IsOpened()==false ) {
     fprintf(fRepErr,"Unable to open: %s\n",strConfigFile);
     return 2;
 }

 error = generic_read_config( config.aL, myConfig );

 if ( error ) {
     myConfig.Delete();
     fprintf(fRepErr,"Error in config file: %s\n",strConfigFile);
 }
 return error;
}

////////////////////////////////////////////////////////////
int do_test (FILE* fOut, const char* strOpt, sOptSed& opt)
{
 const char* strPre1( "iobjs" );
 const char* strPre2( "imedia" );
 const char* strConfig( config_default() );
 unsigned uVal;

 DBGPRINT("DBG: do_test(fOut?%c, %s, ...)\n",
	  ISyORn( fOut!=nil ),
	  strOpt);
 fOut = fOut ? fOut : stdout;

 if ( strOpt && strOpt[ 0 ] ) {
     gString sNew( (char*)strOpt );
     uVal = (unsigned)sNew.Hash();

     switch ( opt.zValue ) {
     case -1:
	 fprintf(fOut,"%d\n",sNew.Hash());
	 break;
     case 0:
	 fprintf(fOut,"%u\n",uVal);
	 break;
     default:
	 fprintf(fOut,"%d\n",uVal % (unsigned)opt.zValue);
	 break;
     }
     return 0;
 }
 fprintf(fOut,"%s:\t%d %d\n",
	 strPre1,
	 LIB_VERSION_ILIB_MAJOR,
	 LIB_VERSION_ILIB_MINOR);
 fprintf(fOut,"%s:\t%d %d\n",
	 strPre2,
	 LIB_IMEDIA_VERSION_MAJOR,
	 LIB_IMEDIA_VERSION_MINOR);

 if ( strConfig && strConfig[ 0 ] ) {
     fprintf(fOut,"config: %s\n",strConfig);
 }

 if ( opt.isVerbose ) {
     printf("ISO %s %s (%u)\n",
	    uniData.Is8859() ? "8859" : "?",
	    uniData.IsIsoLatin() ? "Latin" : "(other)",
	    uniData.inUse->UniTable());
 }

 return 0;
}


int simple_parse (ySkel& skel,
		  const char* searchPath,
		  const char* regExp,
		  FILE* fIn,
		  FILE* fOut,
		  FILE* fRepErr,
		  sOptSed& opt)
{
 int code( 0 );
 int countErrors;

 ASSERTION(fOut,"fOut");
 ASSERTION(fIn,"fIn");

 skel.verboseLevel = opt.verboseLevel;
 skel.sBasePath = opt.sBasePath;

 countErrors = skel.SearchPath( searchPath, fOut );
 if ( countErrors>0 ) {
     if ( fRepErr ) {
	 fprintf(fRepErr, "Ignored %d file(s)\n", countErrors);
     }
 }

 skel.engine.AddLookInto( "extensions:user-class " );

 if ( regExp && strcmp( regExp, "." )==0 ) {
     code = skel.Parse( nil );  // everything!
 }
 else {
     code = skel.Parse( regExp );
 }

 if ( opt.isVeryVerbose ) {
     for (gElem* ptr=skel.engine.StartPtr(); ptr; ptr=ptr->next) {
	 printf("%d\t", ptr->me->iValue);
	 for (int x=1; x<=(ptr->iValue); x++) {
	     printf(" ");
	 }
	 printf("%s\n", ptr->Str());
     }
 }

 if ( opt.zValue ) {
     //printf("lookView:::\n");
     for (gElem* ptr=skel.engine.LookView().StartPtr(); ptr; ptr=ptr->next) {
	 int y( ptr->me->iValue );
	 if ( (opt.zValue & 8)==0 ) {
	     printf("line %d:\t", y);
	 }
	 printf("%s\n", ptr->Str());
     }
 }
 ////printf("%s: stack::: ", skel.parsed.Str( skel.parsed.N() )); skel.engine.stack.Show();

 return code;
}

////////////////////////////////////////////////////////////
int do_run (int cmdNr,
	    gList& args,
	    FILE* fOut,
	    FILE* fRepErr,
	    sOptSed& opt)
{
 int iter( 1 ), nArgs( args.N() ), nIters( nArgs ? nArgs : 1 );
 int thisError( -1 ), error( 0 );

 char* aStr( nil );
 const char* refStr( nil );
 FILE* fIn( stdin );

 ASSERTION(fOut,"fOut");

 gString sArgOne( args.Str( 1 ) );
 gString sArgTwo( args.Str( 2 ) );
 ySkel skel;

 opt.verboseLevel = (int)opt.isVerbose + (int)opt.isVeryVerbose*6;

 switch ( cmdNr ) {
 case 3:
     error = nArgs<2;
     if ( error ) {
	 fprintf(stderr,"At least path and one file expected.\n");
	 return 1;
     }
     if ( sArgOne.Match( "." ) ) {
	 for (iter=2; iter<=nIters; iter++) {
	     skel.Add( args[ iter ] );
	 }
	 error = simple_parse( skel, nil, ".", fIn, fOut, fRepErr, opt );
     }
     else {
	 error = simple_parse( skel, sArgOne.Str(), sArgTwo.Str(), fIn, fOut, fRepErr, opt );
     }
     nIters = 0;
     break;

 default:
     break;
 }

 for ( ; iter<=nIters; iter++) {
     aStr = args[ iter ];
     refStr = nArgs ? aStr : nil;

     switch ( cmdNr ) {
     case 1:	// test
	 thisError = do_test( fOut, aStr, opt );
	 break;

     case 3:
	 break;

     default:
	 IM_ASSERTION_FALSE("uops\n");
     }

     if ( thisError ) {
	 error = thisError;
     }
 }// end FOR (args)

 DBGPRINT("DBG: do_run returns %d\n",error);
 if ( fRepErr ) {
     fprintf(fRepErr, "Error-code: %d\n", error);
 }
 return error;
}

////////////////////////////////////////////////////////////
int go (char** argv, char** envp, int& result)
{
 int error;
 gArg arg( argv, envp );
 sOptSed opt;
 char* str;
 int cmdNr;
 unsigned n( 0 );
 bool isNorm;
 FILE* fOut( stdout );
 FILE* fRepErr( nil );

 arg.AddParams( 1, "-vv|--verbose -h|--help --version\
 -c:%s|--config:%s\
 -b:%s|--base:%s\
 -o:%s|--output:%s\
 -z:%d|--value:%d\
" );

 // Parse command line
 error = arg.FlushParams();
 n = arg.N();
 arg.FindOptionOccurr( "verbose", opt.isVerbose, opt.isVeryVerbose );

 gString firstCmd( arg.Str(1) );
 char* cmdStr( firstCmd.Str() );
 arg.Delete( 1, 1 );

 cmdNr = command_from_str( cmdStr );
 isNorm = (cmdNr==13);

 if ( arg.FindOption("version") ) {
     print_version( arg.Program() );
     return 0;
 }
 if ( arg.FindOption('h') || error!=0 || n==0 ) {
     if ( n>0 && cmdStr[0]!='-' ) {
	 print_help_command( cmdStr );
     }
     else {
	 print_help( str = arg.Program() );
	 printf("For command help, use: %s command --help\n",str);
     }
     return 0;
 }

 if ( opt.isVerbose ) {
     fRepErr = stderr;
 }

 if ( arg.FindOption( 'c', opt.sConfig ) ) {
     error = ycomp_read_config_file( opt.sConfig.Str(), stderr, opt.myConfig );
     if ( error ) return 1;
 }
 else {
     error = ycomp_read_config_file( nil, stderr, opt.myConfig );
     if ( error>0 ) return 1;
 }

 if ( arg.FindOption( 'o', opt.sOutput ) ) {
     if ( isNorm==true || opt.doAll==false ) {
	 fOut = fopen( opt.sOutput.Str(), "wb" );
     }
     else {
	 fOut = fopen( opt.sOutput.Str(), "a" );
     }
     if ( fOut==nil ) return 1;
 }

 if ( arg.FindOption( 'b', opt.sBasePath ) ) {
     ;
 }

 arg.FindOption( "value", opt.zValue );

 if ( cmdNr>0 ) {
     error = do_run( cmdNr, arg, fOut, fRepErr, opt );
 }
 else {
     error = 1;
     fprintf(stderr,"Invalid command: %s\n",cmdStr);
 }

 return error;
}
////////////////////////////////////////////////////////////
int main (int argc, char** argv, char** envp)
{
 int error, result( 0 );

 gINIT;
 error = go( argv, envp, result );
 DBGPRINT("DBG: Objs undeleted: %d\n",gStorageControl::Self().NumObjs());
 gEND;

 DBGPRINT_MIN("go: %d, result=%d\n",error,result);
 return error;
}

