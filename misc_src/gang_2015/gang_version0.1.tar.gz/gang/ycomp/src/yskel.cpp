// yskel.cpp

#include "yskel.h"

// ---------------------------------------------------------

#define COMPLAIN(str,args...) { \
			    complainWarn( str ); \
			    if ( verboseLevel>0 && fOutput!=nil ) { \
			       fprintf(fOutput, "%s:%d: ", refer.sFile.Str(), refer.y); \
			       fprintf(fOutput, args); } \
			  }
// ---------------------------------------------------------

////////////////////////////////////////////////////////////
yNode::~yNode ()
{
}


int yNode::StickInto (gList& stack, gList& view)
{
 gString node;
 gElem* ptr( stack.EndPtr() );
 gElem* pItem( nil );
 const char* strName;
 const char* strItem;

 //printf("to ADD [%s]:\n", Str()); stack.Show(); printf("\n");

 for ( ; ptr; ptr=ptr->prev) {
     strName = ptr->Str();
     DBGPRINT("$$ %-20s strName [%s]\n", Str(), strName);
     if ( strncmp( strName, "container ", strlen( "container " ) )==0 ) {
	 break;
     }
     if ( strncmp( strName, "module ", strlen( "module " ) )==0 ) {
	 break;
     }
 }

 if ( ptr ) {
     for ( ; ptr; ptr=ptr->next) {
	 gString names;
	 gParam name( ptr->Str(), " " );
	 if ( node.Length() ) {
	     node.Add( (char*)"." );
	 }
	 for (pItem=name.StartPtr(); pItem; pItem=pItem->next) {
	     strItem = pItem->Str();
	     if ( strcmp( strItem, "module" )==0 ) {
		 strItem = nil;
	     }
	     if ( strItem ) {
		 if ( names.Length() ) {
		     names.Add( (char*)" " );
		 }
		 names.Add( (char*)strItem );
	     }
	 }
	 node.AddString( names );
	 //node.Add( ptr->Str() );
     }
 }
 else {
     node.Set( Str() );
 }

 view.Add( node );
 view.EndPtr()->me->iValue = iValue;
 DBGPRINT("$$ node [%s]\n\n", node.Str());

 return 0;
}

////////////////////////////////////////////////////////////
yEngine::yEngine ()
    : ptrRef( nil )
{
}


yEngine::~yEngine ()
{
}


int yEngine::Input (gString& sLine, int zColumn)
{
 if ( sLine.IsEmpty() ) {
     return 0;
 }

 char lastChr( sLine[ sLine.Length() ] );
 unsigned posOpen( sLine.Find( '{' ) );
 unsigned posClose( sLine.Find( '}' ) );
 bool hasLookInto( strstr( lookInto.Str( 1 ), ":" ) );

 Add( sLine );
 EndPtr()->iValue = zColumn;  // column in the yang source
 (EndPtr()->me)->iValue = ptrRef->y;

 DBGPRINT("%d\t%s\n", ptrRef->y, sLine.Str());  // interesting raw text output!

 // Look into...
 if ( lookInto.N() ) {
     if ( posOpen && posClose ) return 0;

     if ( posOpen ) {
	 gString sCopy( sLine );
	 if ( lastChr=='{' ) sCopy.Delete( sCopy.Length() );
	 sCopy.Trim();
	 yNode* newNode( new yNode( sCopy ) );
	 ASSERTION(newNode,"newNode");  // out of memory?
	 stack.AppendObject( newNode );
	 stack.EndPtr()->me->iValue = ptrRef->y;
	 DBGPRINT("::: PUSH %s\n", sCopy.Str());
     }

    if ( posClose ) {
	if ( stack.N() ) {
	    if ( hasLookInto ) {
		if ( 1 /* stack.EndPtr()->iValue==sLine.Length() */ ) {
		    DBGPRINT("::: POP %s\n", stack.EndPtr()->Str());
		    //lookView.Add( stack.EndPtr()->Str() );
		    //lookView.EndPtr()->me->iValue = stack.EndPtr()->me->iValue;
		    ((yNode*)stack.EndPtr()->me)->StickInto( stack, lookView );
		    stack.Delete( stack.N() );
		}
	    }// stack N
	}
	else {
	    fprintf(stderr, "%s:%d: stack uops: %s\n", ptrRef->sFile.Str(), ptrRef->y, sLine.Str());
	    underflow.Add( sLine );
	    underflow.EndPtr()->me->iValue = ptrRef->y;
	}
    }

    if ( posOpen==0 && posClose==0 && lastChr==';' ) {
	gString sCopy( sLine );
	sCopy.Delete( sCopy.Length() );
	sCopy.Trim();

	if ( sCopy.Length() ) {
	    yNode* newNode( new yNode( sCopy ) );
	    ASSERTION(newNode,"newNode");  // out of memory?
	    stack.AppendObject( newNode );
	    stack.EndPtr()->me->iValue = ptrRef->y;
	    ((yNode*)stack.EndPtr()->me)->StickInto( stack, lookView );
	    stack.Delete( stack.N() );
	}
    }
 }

 return 0;
}


int yEngine::AddLookInto (const char* strLook)
{
 if ( strLook==nil ) return -1;
 lookInto.Add( (char*)strLook );
 return 0;
}

////////////////////////////////////////////////////////////
ySkel::ySkel ()
    : verboseLevel( 0 ),
      fOutput( stdout ),
      fReport( stderr )
{
}


ySkel::~ySkel ()
{
}


int ySkel::SearchPath (const char* strPath, FILE* fOut, FILE* fErrors)
{
 int countErrors( 0 );
 unsigned pos;
 gString sExt( (char*)strPath );

 if ( fOut ) {
     fOutput = fOut;
 }
 if ( fErrors ) {
     fReport = fErrors;
 }

 ASSERTION(fOutput,"not even stdout?");
 ASSERTION(fReport,"uops");

 if ( (pos = sExt.FindBack( '.' )) > 1 ) {
     sExt.Delete( 1, pos-1 );
 }

 // e.g. c:/repos/hiTModelSpec/modules/

 // In case strPath is a '*.txt' or '*.lst' file, use its contents
 if ( sExt.Match( (char*)".txt" ) || sExt.Match( (char*)".lst" ) ) {
     gFileFetch fetch( (char*)strPath );
     countErrors = thisCopyFNamesIntoList( fetch.aL, ".yang", *this );
     DBGPRINT("DBG: read {%s}, %u line(s), ignored lines: %d\n", strPath, fetch.aL.N(), countErrors);
 }
 else {
     if ( strPath ) {
	 fprintf(fReport, "Not implemented path search: %s\n", strPath);
     }
     return -1;
 }

 return countErrors;
}


int ySkel::Parse (const char* regExp)
{
 int code( 0 );
 int thisError;
 gElem* pElem;
 const char* strFilename;
 gString sRegExp( (char*)regExp );

 SubstSlashes( sRegExp );

 if ( regExp==nil ) {
     if ( verboseLevel ) {
	 fprintf(fOutput, "Handling %u file(s)\n", N());
     }
     // parse them all
     for (pElem=StartPtr(); pElem; pElem=pElem->next) {
	 strFilename = pElem->Str();
	 thisError = thisParse( strFilename );
	 if ( thisError ) {
	     code = thisError;
	 }
     }
 }
 else {
     // parse those matching regExp
     for (pElem=StartPtr(); pElem; pElem=pElem->next) {
	 strFilename = pElem->Str();
	 gString sName( (char*)strFilename );
	 if ( sName.Find( sRegExp, true ) ) {
	     thisError = thisParse( strFilename );
	     if ( thisError ) {
		 code = thisError;
	     }
	 }
     }
 }
 return code;
}


int ySkel::ParseFiles ()
{
 int code( Parse( nil ) );
 return code;
}


char* ySkel::FileExtension (const char* strFile)
{
 int idx, length;
 if ( strFile==nil ) return nil;

 length = strlen( strFile );
 for (idx=length-1; idx>0; idx--) {
     if ( strFile[ idx ]=='.' ) return (char*)(strFile+idx);
 }
 return nil;
}


void ySkel::SubstSlashes (gString& io)
{
#ifdef iDOS_SPEC
 for (int idx=1; idx<(int)io.Length(); idx++) {
     if ( io[ idx ]=='/' ) {
	 io[ idx ] = '\\';
     }
 }
#endif
}


int ySkel::thisParse (const char* yangFile)
{
 int code;
 int ioError;
 FILE* fIn;

 ASSERTION(fReport,"uops");
 ASSERTION(yangFile,"yangFile");

 DBGPRINT("DBG: thisParse {%s}\n", yangFile);

 fIn = fopen( yangFile, "r" );
 ioError = fIn==nil;

 if ( ioError ) {
     fprintf(stderr, "Parsing: %s, NO FILE\n", yangFile);
     return 2;
 }

 parsed.Add( (char*)yangFile );

 if ( verboseLevel ) {
     fprintf(fOutput, "Parsing: %s\n", yangFile);
 }

 refer.SetAs( yangFile );
 code = thisHandledParse( fileno( fIn ) );

 fclose( fIn );
 DBGPRINT("DBG: parse ended %s: %d\n", yangFile, code);
 return code;
}


int ySkel::thisHandledParse (int handle)
{
 const int maskDoubleQ( 1 );
 const int maskSingleQ( 2 );
 const int maskDoubleSlash( 16 );
 const int maskComment( 32 );
 int state( 0 );
 int readIO;
 t_uchar current, previous( '\0' );

 ASSERTION(handle!=-1,"-1");

 for ( ; (readIO = read( handle, &current, 1 ))==1; previous=current) {
     if ( current=='\r' ) continue;  // ignore carriage-returns completely

     refer.x++;
     if ( current=='\n' ) {
	 parseFlushLine();
	 refer.x = 1;
	 refer.y++;
	 refer.sLine.Delete();
	 state &= ~maskDoubleSlash;
	 continue;
     }
     if ( current=='\t' ) {
	 current = ' ';
     }
     if ( current<' ' ) {
	 COMPLAIN( "Invalid character", "ASCII %dd\n", (int)current );
	 continue;
     }
     if ( current>=127 ) {
	 //COMPLAIN( "UCS8 character", "ASCII %dd ('%c')\n", (int)current, current );
     }

     if ( state==0 ) {
	 if ( current=='/' && previous=='/' ) {
	     state |= maskDoubleSlash;
	     // Delete remanescent char
	     if ( refer.sLine[ refer.sLine.Length() ]==previous ) refer.sLine.Delete( refer.sLine.Length() );
	 }
	 
	 if ( current=='*' && previous=='/' ) {  // /*** styled comments ***/
	     state |= maskComment;
	     // Delete remanescent char
	     if ( refer.sLine[ refer.sLine.Length() ]==previous ) refer.sLine.Delete( refer.sLine.Length() );
	 }

	 if ( current=='"' ) {
	     state |= maskDoubleQ;
	 }
	 if ( current=='\'' ) {
	     state |= maskSingleQ;
	 }
     }
     else {
	 if ( (state & maskComment) && current=='/' && previous=='*' ) {  // /*** styled comments ***/
	     state &= ~maskComment;
	     continue;  // avoid dangling symbols (star and slash)
	 }

	 if ( state==maskDoubleQ ) {
	     if ( current=='"' ) {
		 state &= ~maskDoubleQ;
		 continue;  // avoid dangling symbol
	     }
	 }

	 if ( state==maskSingleQ ) {
	     if ( current=='\'' ) {
		 state &= ~maskSingleQ;
		 continue;  // avoid dangling symbol
	     }
	 }
     }//end ELSE

     if ( state==0 ) {
	 refer.sLine.Add( current );
     }
 }

 // error when either state is not zero, or stack is not empty;
 // also underflow returns 8
 if ( engine.underflow.N() ) return 8;
 if ( engine.stack.N() ) return 4;
 return state!=0;
}


int ySkel::thisCopyFNamesIntoList (gList& input, const char* strExt, gList& output)
{
 int countErrors( 0 );
 const char* thisExt;

 for (gElem* pElem=input.StartPtr(); pElem; pElem=pElem->next) {
     gString sName( pElem->Str() );
     sName.Trim();

     if ( sName[ 1 ]>' ' && sName[ 1 ]!='#' ) {
	 thisExt = FileExtension( sName.Str() );
	 if ( thisExt && strcmp( thisExt, ".yang" )==0 ) {
	     gString sFullPath( sBasePath );
	     if ( sFullPath[ sFullPath.Length() ]!=gSLASHCHR ) {
		 sFullPath.Add( gSLASHCHR );
	     }
	     sFullPath.AddString( sName );
	     output.Add( sFullPath );
	 }
	 else {
	     countErrors++;
	 }
     }
 }
 return countErrors;
}


int ySkel::parseFlushLine ()
{
 gString sTrim( refer.sLine );

 sTrim.Trim();
 engine.ptrRef = &refer;
 engine.Input( sTrim, (int)refer.sLine.Length() - (int)sTrim.Length() );

 if ( verboseLevel<=0 ) {
     if ( refer.nWarns ) {
	 fprintf(fOutput, "Warns %d: %s\n", refer.nWarns, sTrim.Str());
     }
 }

 refer.nWarns = 0;

 return 0;
}


void ySkel::complainWarn (const char* strComplain)
{
 refer.nWarns++;

 if ( verboseLevel ) {
     fprintf(fReport, "%s:%d: column %d, warn: %s\n",
	     refer.sFile.Str(),
	     refer.y, refer.x,
	     strComplain);
 }
}

////////////////////////////////////////////////////////////

