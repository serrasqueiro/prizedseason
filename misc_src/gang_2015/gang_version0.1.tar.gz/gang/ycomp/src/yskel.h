#ifndef SKEL_X_H
#define SKEL_X_H

#include "lib_iobjs.h"

////////////////////////////////////////////////////////////
// Common enums
// ---------------------------------------------------------


////////////////////////////////////////////////////////////
// Common structs
// ---------------------------------------------------------
struct sReference {
    sReference ()
	: y( 0 ), x( 0 ),
	  nWarns( 0 ) {
    }

    ~sReference () {
    }

    gString sFile;
    gString sLine;
    int y, x;
    int nWarns;

    void Reset () {
	sFile.Reset();
	sLine.Reset();
	x = y = 0;
	nWarns = 0;
    }

    void SetAs (const char* strFile) {
	Reset();
	y = 1;
	sFile.Set( (char*)strFile );
    }
};

////////////////////////////////////////////////////////////
class yNode : public gList {
public:
    yNode () {
    }

    yNode (gString& s) {
	Add( s );
    }

    virtual ~yNode () ;

    virtual int StickInto (gList& stack, gList& view) ;

private:
    //Operators,empty
    yNode (yNode& ) ; //empty
    yNode& operator= (yNode& ) ; //empty
};


////////////////////////////////////////////////////////////
class yEngine : public gList {
public:
    yEngine () ;
    virtual ~yEngine () ;

    sReference* ptrRef;
    gList stack;
    gList underflow;

    virtual int Input (gString& sLine, int zColumn=0) ;

    virtual int AddLookInto (const char* strLook) ;

    // Get methods
    gList& LookView () {
	return lookView;
    }

protected:
    gList lookInto;
    gList lookView;

private:
    //Operators,empty
    yEngine (yEngine& ) ; //empty
    yEngine& operator= (yEngine& ) ; //empty
};

////////////////////////////////////////////////////////////
class ySkel : public gList {
public:
    ySkel () ;
    virtual ~ySkel () ;

    // Public data-members
    int verboseLevel;
    gString sBasePath;
    sReference refer;
    yEngine engine;
    gList parsed;

    // Methods, etc.
    virtual int SearchPath (const char* strPath, FILE* fOut=nil, FILE* fErrors=nil) ;

    virtual int Parse (const char* regExp) ;

    virtual int ParseFiles () ;

    char* FileExtension (const char* strFile) ;

    // Useful methods
    void SubstSlashes (gString& io) ;

protected:
    FILE* fOutput;
    FILE* fReport;

    int thisParse (const char* yangFile) ;

    int thisHandledParse (int handle) ;

    int thisCopyFNamesIntoList (gList& input, const char* strExt, gList& output) ;

private:
    int parseFlushLine () ;

    void complainWarn (const char* strComplain) ;

    //Operators,empty
    ySkel (ySkel& ) ; //empty
    ySkel& operator= (ySkel& ) ; //empty
};

////////////////////////////////////////////////////////////
#endif //SKEL_X_H

